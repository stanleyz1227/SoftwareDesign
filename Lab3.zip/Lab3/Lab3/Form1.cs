﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public double input;
        public double current_result;
        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.DarkGray;
            this.CenterToScreen();
            textBox2.Text = "0";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void add_button_Click(object sender, EventArgs e)
        {
            try
            {
                input = Convert.ToDouble(textBox1.Text);
                current_result = Convert.ToDouble(textBox2.Text);
                current_result += input;
                textBox2.Text = current_result.ToString();
                textBox1.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid or missing value!");
            }
        }

        private void sub_button_Click(object sender, EventArgs e)
        {
            try
            {
                input = Convert.ToDouble(textBox1.Text);
                current_result = Convert.ToDouble(textBox2.Text);
                current_result -= input;
                textBox2.Text = current_result.ToString();
                textBox1.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid or missing value!");
            }
        }

        private void mul_button_Click(object sender, EventArgs e)
        {
            try
            {
                input = Convert.ToDouble(textBox1.Text);
                current_result = Convert.ToDouble(textBox2.Text);
                current_result *= input;
                textBox2.Text = current_result.ToString();
                textBox1.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid or missing value!");
            }
        }

        private void div_button_Click(object sender, EventArgs e)
        {
            try
            {
                input = Convert.ToDouble(textBox1.Text);
                current_result = Convert.ToDouble(textBox2.Text);
                current_result /= input;
                textBox2.Text = current_result.ToString();
                textBox1.Clear();
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid or missing value!");
            }
        }

        private void clear_button_Click(object sender, EventArgs e)
        {
            textBox2.Text = "0";
        }
    }
}
