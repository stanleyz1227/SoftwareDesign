﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Drawing.Drawing2D;

namespace Lab2
{
    public partial class Form1 : Form
    {
        private ArrayList coordinates = new ArrayList();
        public Point p1;
        public Point p2;
        public int x1;
        public int y1;
        public int x2;
        public int y2;
        public Form1()
        {
            InitializeComponent();
            this.Text = "Stanley Zhang - Lab 2";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.button1.Text == "Show Lines")
            {
                this.button1.Text = "Hide Lines";
            }
            else if(this.button1.Text == "Hide Lines")
            {
                this.button1.Text = "Show Lines";
            }
            this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            
            Graphics g = e.Graphics;
        
            const int WIDTH = 20;
            const int HEIGHT = 20;
            Pen blackPen1 = new Pen(Color.Black, 2);
            if (this.button1.Text == "Hide Lines")
            {

                Pen blackPen2 = new Pen(Color.Black, 1);

                for (int i = 0; i < coordinates.Count - 1; i++)
                {
                    p1 = (Point)coordinates[i];
                    p2 = (Point)coordinates[i + 1];
                    x1 = p1.X;
                    y1 = p1.Y;
                    x2 = p2.X;
                    y2 = p2.Y;
                    g.DrawLine(blackPen2, x1, y1, x2, y2);
                }
            }
            foreach (Point p in this.coordinates)
            {
                g.DrawEllipse(blackPen1, p.X - WIDTH / 2, p.Y - WIDTH / 2,
                WIDTH, HEIGHT);
                g.FillEllipse(Brushes.Red,
                p.X - WIDTH / 2, p.Y - WIDTH / 2,
                WIDTH, HEIGHT);
            }
          
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point p = new Point(e.X, e.Y);
                this.coordinates.Add(p);
                this.Invalidate();
            }
            if (e.Button == MouseButtons.Right)
            {
                this.coordinates.Clear();
                this.Invalidate();
            }

        }
    }
}
