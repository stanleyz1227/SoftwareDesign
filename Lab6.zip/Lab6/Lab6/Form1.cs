﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Form1 : Form
    {
        public Pen blackPen = new Pen(Color.Black, 3);
        public SettingsDialog myDialog = new SettingsDialog();
        public List<Shape> shapes = new List<Shape>();
        public bool isFirstClick = true;
        public bool isFirstClickEver = true;
        public int firstClickx;
        public int firstClicky;
        public bool removed = false;

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine("hello");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myDialog.ShowDialog();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shapes.Clear();
            panel2.Invalidate();
            removed = true;
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            shapes.RemoveAt(shapes.Count - 1);
            panel2.Invalidate();
            removed = true;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        protected override void OnPaint(PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (isFirstClick == true && isFirstClickEver == false)
            {
                g.FillEllipse(Brushes.Black, firstClickx, firstClicky, 10, 10);
                isFirstClick = false;
            }     
            else if (isFirstClick == false && removed == false)
            {
                isFirstClick = true;
            }
            else if (isFirstClick == false && removed == true)
            {
                g.FillEllipse(Brushes.Black, firstClickx, firstClicky, 10, 10);
                removed = false;
            }

            foreach (Shape s in shapes)
            {
                s.Draw(g);
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            //hit test
            //if second mouse click, object is created and added to list
            isFirstClickEver = false;
            if (isFirstClick == true)
            {
                firstClickx = e.X;
                firstClicky = e.Y;
                panel2.Invalidate();
            }
            else if(isFirstClick == false)
            {
                //Line
                if (radioButton1.Checked)
                {
                    //No outline and no fill
                    if (myDialog.penColor == 0 && myDialog.fillColor == 0)
                    {
                        MessageBox.Show("Fill and or pen/outline color must be selected");
                    }

                    //If just fill and no outline, do nothing

                    //If outline color selected, add line to shapes to be drawn
                    else if (myDialog.penColor == 1)
                        shapes.Add(new Line(new Pen(Brushes.Black, myDialog.penWidth + 1), firstClickx, firstClicky, e.X, e.Y));
                    else if (myDialog.penColor == 2)
                        shapes.Add(new Line(new Pen(Brushes.Red, myDialog.penWidth + 1), firstClickx, firstClicky, e.X, e.Y));
                    else if (myDialog.penColor == 3)
                        shapes.Add(new Line(new Pen(Brushes.Blue, myDialog.penWidth + 1), firstClickx, firstClicky, e.X, e.Y));
                    else if (myDialog.penColor == 4)
                        shapes.Add(new Line(new Pen(Brushes.Green, myDialog.penWidth + 1), firstClickx, firstClicky, e.X, e.Y));
                }
                //Rectangle
                else if (radioButton2.Checked)
                {
                    //No outline and no fill
                    if (myDialog.penColor == 0 && myDialog.fillColor == 0)
                    {
                        MessageBox.Show("Fill and or pen/outline color must be selected");
                    }
                    //No fill
                    else if (myDialog.fillColor == 0)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Black, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Red, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Blue, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Green, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));

                    }
                    //Black fill
                    else if (myDialog.fillColor == 1)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Rectangle(Brushes.Black, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Red fill
                    else if (myDialog.fillColor == 2)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Rectangle(Brushes.Red, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Rectangle(Brushes.Red, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Rectangle(Brushes.Red, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Rectangle(Brushes.Red, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Rectangle(Brushes.Red, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Blue fill
                    else if (myDialog.fillColor == 3)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Rectangle(Brushes.Blue, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Rectangle(Brushes.Blue, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Rectangle(Brushes.Blue, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Rectangle(Brushes.Blue, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Rectangle(Brushes.Blue, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Green fill
                    else if (myDialog.fillColor == 4)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Rectangle(Brushes.Green, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Rectangle(Brushes.Green, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Rectangle(Brushes.Green, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Rectangle(Brushes.Green, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Rectangle(Brushes.Green, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }

                }
                //Ellipse
                else if (radioButton3.Checked)
                {
                    //No outline and no fill
                    if (myDialog.penColor == 0 && myDialog.fillColor == 0)
                    {
                        MessageBox.Show("Fill and or pen/outline color must be selected");
                    }
                    //No fill
                    else if (myDialog.fillColor == 0)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Black, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Red, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Blue, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Green, myDialog.penWidth + 1), true, false, firstClickx, firstClicky, e.X, e.Y));

                    }
                    //Black fill
                    else if (myDialog.fillColor == 1)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Ellipse(Brushes.Black, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Red fill
                    else if (myDialog.fillColor == 2)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Ellipse(Brushes.Red, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Ellipse(Brushes.Red, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Ellipse(Brushes.Red, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Ellipse(Brushes.Red, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Ellipse(Brushes.Red, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Blue fill
                    else if (myDialog.fillColor == 3)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Ellipse(Brushes.Blue, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Ellipse(Brushes.Blue, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Ellipse(Brushes.Blue, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Ellipse(Brushes.Blue, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Ellipse(Brushes.Blue, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                    //Green fill
                    else if (myDialog.fillColor == 4)
                    {
                        if (myDialog.penColor == 1)
                            shapes.Add(new Ellipse(Brushes.Green, new Pen(Brushes.Black, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 2)
                            shapes.Add(new Ellipse(Brushes.Green, new Pen(Brushes.Red, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 3)
                            shapes.Add(new Ellipse(Brushes.Green, new Pen(Brushes.Blue, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 4)
                            shapes.Add(new Ellipse(Brushes.Green, new Pen(Brushes.Green, myDialog.penWidth + 1), false, false, firstClickx, firstClicky, e.X, e.Y));
                        else if (myDialog.penColor == 0)
                            shapes.Add(new Ellipse(Brushes.Green, new Pen(Brushes.Green, 0), false, true, firstClickx, firstClicky, e.X, e.Y));
                    }
                }
                panel2.Invalidate();
            }
            
        }
    }
    public class Shape
    {
        public virtual void Draw(Graphics g)
        {
        }
    }

    public class Line: Shape
    {
        public int X1;
        public int X2;
        public int Y1;
        public int Y2;
        public Pen OutlinePen;

        public Line(Pen outlinePen, int x1, int y1, int x2, int y2)
        {
            X1 = x1;
            X2 = x2;
            Y1 = y1;
            Y2 = y2;
            OutlinePen = outlinePen;
        }

        public override void Draw(Graphics g)
        {
            g.DrawLine(OutlinePen, X1, Y1, X2, Y2);
            base.Draw(g);
        }
    }

    public class Rectangle : Shape
    {
        public int X1;
        public int X2;
        public int Y1;
        public int Y2;
        public Brush FillBrush;
        public Pen OutlinePen;
        public bool NoFill;
        public bool NoOutline;

        public Rectangle(Brush fillBrush, Pen outlinePen, bool noFill, bool noOutline, int x1, int y1, int x2, int y2)
        {
            X1 = x1;
            X2 = x2;
            Y1 = y1;
            Y2 = y2;
            FillBrush = fillBrush;
            OutlinePen = outlinePen;
            NoFill = noFill;
            NoOutline = noOutline;
        }

        public override void Draw(Graphics g)
        {
            int width = Math.Abs(X2 - X1);
            int height = Math.Abs(Y2 - Y1);
            int leftMostx;
            int upMosty;
            if (X2 <= X1 && Y2 <= Y1)
            {
                leftMostx = X2;
                upMosty = Y2;
            }
            else if (X2 <= X1 && Y2 > Y1)
            {
                leftMostx = X2;
                upMosty = Y1;
            }
            else if (X2 > X1 && Y2 > Y1)
            {
                leftMostx = X1;
                upMosty = Y1;
            }
            else 
            {
                leftMostx = X1;
                upMosty = Y2;
            }
            if (NoFill)
                g.DrawRectangle(OutlinePen, leftMostx, upMosty, width, height);
            else if (NoOutline)
                g.FillRectangle(FillBrush, leftMostx, upMosty, width, height);
            else
            {
                g.DrawRectangle(OutlinePen, leftMostx, upMosty, width, height);
                g.FillRectangle(FillBrush, leftMostx, upMosty, width, height);
            }
            base.Draw(g);
        }
    }

    public class Ellipse : Shape
    {
        public int X1;
        public int X2;
        public int Y1;
        public int Y2;
        public Brush FillBrush;
        public Pen OutlinePen;
        public bool NoFill;
        public bool NoOutline;

        public Ellipse(Brush fillBrush, Pen outlinePen, bool noFill, bool noOutline, int x1, int y1, int x2, int y2)
        {
            X1 = x1;
            X2 = x2;
            Y1 = y1;
            Y2 = y2;
            FillBrush = fillBrush;
            OutlinePen = outlinePen;
            NoFill = noFill;
            NoOutline = noOutline;
        }

        public override void Draw(Graphics g)
        {
            int width = Math.Abs(X2 - X1);
            int height = Math.Abs(Y2 - Y1);
            int leftMostx;
            int upMosty;
            if (X2 <= X1 && Y2 <= Y1)
            {
                leftMostx = X2;
                upMosty = Y2;
            }
            else if (X2 <= X1 && Y2 > Y1)
            {
                leftMostx = X2;
                upMosty = Y1;
            }
            else if (X2 > X1 && Y2 > Y1)
            {
                leftMostx = X1;
                upMosty = Y1;
            }
            else
            {
                leftMostx = X1;
                upMosty = Y2;
            }
            if (NoFill)
                g.DrawEllipse(OutlinePen, leftMostx, upMosty, width, height);
            else if (NoOutline)
                g.FillEllipse(FillBrush, leftMostx, upMosty, width, height);
            else
            {
                g.DrawEllipse(OutlinePen, leftMostx, upMosty, width, height);
                g.FillEllipse(FillBrush, leftMostx, upMosty, width, height);
            }
            base.Draw(g);
        }
    }
}
