﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class SettingsDialog : Form
    {
        public int penColor;
        public int fillColor;
        public int penWidth;

        public SettingsDialog()
        {
            InitializeComponent();
            penColor = 0;
            fillColor = 0;
            penWidth = 0;
        }

        private void SettingsDialog_Load(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = penColor;
            listBox2.SelectedIndex = fillColor;
            listBox3.SelectedIndex = penWidth;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            listBox1.SelectedIndex = penColor;
            listBox2.SelectedIndex = fillColor;
            listBox3.SelectedIndex = penWidth;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hide();
            penColor = listBox1.SelectedIndex;
            fillColor = listBox2.SelectedIndex;
            penWidth = listBox3.SelectedIndex;
        }
    }
}
