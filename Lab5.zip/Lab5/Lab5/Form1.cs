﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Form1 : Form
    {
        public Grid myGrid = new Grid(50,25);
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //call Generate for new gen
            //Invalidate
            Grid newg = myGrid.Generate();
            myGrid = newg;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Pen blackPen = new Pen(Color.Black, 1);
            Graphics g = e.Graphics;
            for (int i = 0; i < 25; i++)
            {
                for (int j = 0; j < 50; j++)
                {
                    if (myGrid[j,i])
                        g.FillRectangle(Brushes.Black, j * 20 + 10, i * 20 + 70, 20, 20);
                    else
                        g.DrawRectangle(blackPen, j*20+10, i*20+70, 20, 20);
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            //stop button
            timer1.Enabled = false;
            button1.Enabled = true;
            button2.Enabled = true;
            button4.Enabled = false;
            button3.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //start button
            timer1.Enabled = true;
            button1.Enabled = false;
            button2.Enabled = false;
            button4.Enabled = true;
            button3.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //next gen button
            //call Generate for new gen
            //Invalidate
            Grid newg = myGrid.Generate();
            myGrid = newg;
            Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //clear button
            myGrid = new Grid(50, 25);
            Invalidate();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < 25; i++)
            {
                for (int j = 0; j < 50; j++)
                {
                    if (e.X > j*20+10 && e.X <= j*20+30 && e.Y > i*20+70 && e.Y <= i*20+90)
                    {
                        myGrid[j,i] = true;
                    }
                }
            }
            Invalidate();
        }
    }
    public class Grid
    {
        public bool [,] grid;
        public Grid(int x, int y)
        {
          grid = new bool[x, y];
        }

        public bool this[int x, int y]
        {
            get
            {
                //Check bounds
                if (x >= 0 && x < 50 && y >= 0 && y < 25)
                    return grid[x, y];
                return false;
            }

            set
            {
                //Check bounds
                if (x >= 0 && x < 50 && y >= 0 && y < 25)
                    grid[x,y] = value;
            }
        }

        private int Neighbors(int x, int y)
        {
            int count = 0;
            if (this[x - 1, y])
                count++;
            if (this[x + 1, y])
                count++;
            if (this[x - 1, y - 1])
                count++;
            if (this[x + 1, y - 1])
                count++;
            if (this[x, y - 1])
                count++;
            if (this[x, y + 1])
                count++;
            if (this[x - 1, y + 1])
                count++;
            if (this[x + 1, y + 1])
                count++;
            return count;
        }

        public Grid Generate()
        {
            //birth if neighbors = 3, death if neighbors < 2 or > 3
            Grid newg = new Grid(50, 25);
            for (int i = 0; i < 50; i++)
            {
                for (int j = 0; j < 25; j++)
                {
                    int numNeighbors = this.Neighbors(i, j);
                    if (numNeighbors == 3)
                        newg[i, j] = true;
                    else if (numNeighbors < 2 || numNeighbors > 3)
                        newg[i, j] = false;
                    else
                        newg[i, j] = this[i, j];
                }
            }
            return newg;
        }
    }
}
