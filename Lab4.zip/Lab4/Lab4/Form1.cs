﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private bool[,] board = new bool[8, 8];

        protected override void OnPaint(PaintEventArgs e)
        {
            //Draw board
            Pen blackPen = new Pen(Color.Black, 1);
            Graphics g = e.Graphics;
            float xco = 150;
            float yco = 100;
            int row = 0;
            while (yco <= 450)
            {
               while (xco <= 450)
                {
                    g.FillRectangle(Brushes.Black, xco, yco, 50, 50);
                    xco += 100;
                }
                yco += 50;
                if (row == 0)
                {
                    xco = 100;
                    row = 1;
                }
                else
                {
                    xco = 150;
                    row = 0;
                }
            }
            g.DrawRectangle(blackPen, 100, 100, 400, 400);

            Console.WriteLine("Board:");
            //Draw queens
            String Q = "Q";
            Font drawFont = new Font("Arial", 30, FontStyle.Bold);
            SolidBrush blackBrush = new SolidBrush(Color.Black);
            SolidBrush whiteBrush = new SolidBrush(Color.White);

            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Console.WriteLine(board[r, c]);
                    if (board[c, r])
                    {
                        if (r % 2 == 0)
                        {
                            if (c % 2 == 0)
                            {
                                //Draw black Q
                                g.DrawString(Q, drawFont, blackBrush, 50 * c + 102, 50 * r + 102);
                            }
                            else
                            {
                                //Draw white Q
                                g.DrawString(Q, drawFont, whiteBrush, 50 * c + 102, 50 * r + 102);
                            }
                        }
                        else
                        {
                            if (c % 2 == 0)
                            {
                                //Draw white Q
                                g.DrawString(Q, drawFont, whiteBrush, 50 * c + 102, 50 * r + 102);
                            }
                            else
                            {
                                //Draw black Q
                                g.DrawString(Q, drawFont, blackBrush, 50 * c + 102, 50 * r + 102);
                            }
                        }
                    }
                }   
                Console.WriteLine();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int row = 0;
            board = new bool[8, 8]; //clear board]
            //Set row in column 0 from selected radio button
            //row = selection;
            if (radioButton1.Checked)
                row = 0;
            else if (radioButton2.Checked)
                row = 1;
            else if (radioButton3.Checked)
                row = 2;
            else if (radioButton4.Checked)
                row = 3;
            else if (radioButton5.Checked)
                row = 4;
            else if (radioButton6.Checked)
                row = 5;
            else if (radioButton7.Checked)
                row = 6;
            else if (radioButton8.Checked)
                row = 7;
            Console.WriteLine(row);
            board[0, row] = true;
            PlaceQueen(1);  //start at column 1
            Invalidate();   //draw board

        }

        //This is the recursive solution
        private bool PlaceQueen(int col)
        {
            for (int row = 0; row <= 7; ++row)
            {
                if (IsSafe(col, row))
                {
                    board[col, row] = true; //place queen
                    if (col == 7)
                        return true;    //we have a solution
                    else
                    {
                        if (PlaceQueen(col + 1))    //continue to next column
                            return true;
                        else
                            board[col, row] = false;   //retract move and look for another safe square
                    }
                }
            }
            return false;   //no safe columns left so backtrack
        }

        private bool IsSafe(int column, int row)
        {
            //check column
            for (int i = 0; i < 8; i++)
            {
                if (board[i, row])
                    return false;
            }
            //check row
            for (int i = 0; i < 8; i++)
            {
                if (board[column, i])
                    return false;
            }
            //check diagonals
            int c = column;
            int r = row;
            while (c != -1 && r != -1 && c != 8 && r != 8)
            {
                c--;
                r--;
                if (c >= 0 && r >= 0 && c <= 7 && r <= 7)
                {
                    if (board[c, r])
                        return false;
                }
            }
            c = column;
            r = row;
            while (c != -1 && r != -1 && c != 8 && r != 8)
            {
                c--;
                r++;
                if (c >= 0 && r >= 0 && c <= 7 && r <= 7)
                {
                    if (board[c, r])
                        return false;
                }
            }
            c = column;
            r = row;
            while (c != -1 && r != -1 && c != 8 && r != 8)
            {
                c++;
                r++;
                if (c >= 0 && r >= 0 && c <= 7 && r <= 7)
                {
                    if (board[c, r])
                        return false;
                }
            }
            c = column;
            r = row;
            while (c != -1 && r != -1 && c != 8 && r != 8)
            {
                c++;
                r--;
                if (c >= 0 && r >= 0 && c <= 7 && r <= 7)
                {
                    if (board[c, r])
                        return false;
                }
            }
            return true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
    }
    
